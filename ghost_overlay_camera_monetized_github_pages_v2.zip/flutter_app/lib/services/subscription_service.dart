import 'package:shared_preferences/shared_preferences.dart';

class SubscriptionService {
  static const int maxFreeReferences = 3;
  static const String _usedRefsKey = 'used_reference_count';
  static const String _proExpiryKey = 'pro_expiry_epoch';

  static Future<int> getUsedReferences() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_usedRefsKey) ?? 0;
  }

  static Future<int> getRemainingFreeReferences() async {
    final used = await getUsedReferences();
    return (maxFreeReferences - used).clamp(0, maxFreeReferences);
  }

  static Future<bool> isProActive() async {
    final prefs = await SharedPreferences.getInstance();
    final expiry = prefs.getInt(_proExpiryKey) ?? 0;
    return DateTime.now().millisecondsSinceEpoch < expiry;
  }

  static Future<bool> canUploadReference() async {
    if (await isProActive()) return true;
    final used = await getUsedReferences();
    return used < maxFreeReferences;
  }

  static Future<void> recordReferenceUpload() async {
    if (await isProActive()) return;
    final prefs = await SharedPreferences.getInstance();
    final used = prefs.getInt(_usedRefsKey) ?? 0;
    await prefs.setInt(_usedRefsKey, used + 1);
  }

  /// Activates 1-Month Pro Pass for ₹499
  static Future<void> activateOneMonthPro() async {
    final prefs = await SharedPreferences.getInstance();
    final expiry = DateTime.now().add(const Duration(days: 30)).millisecondsSinceEpoch;
    await prefs.setInt(_proExpiryKey, expiry);
  }
}
