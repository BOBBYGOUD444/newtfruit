import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'screens/home_screen.dart';

List<CameraDescription> availableSystemCameras = [];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  try {
    availableSystemCameras = await availableCameras();
  } catch (e) {
    debugPrint("Failed to fetch cameras: $e");
  }

  runApp(const GhostCameraApp());
}

class GhostCameraApp extends StatelessWidget {
  const GhostCameraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ghost Overlay Camera',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Colors.white,
      ),
      home: HomeScreen(cameras: availableSystemCameras),
    );
  }
}
