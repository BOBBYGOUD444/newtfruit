import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:image_picker/image_picker.dart';
import 'package:gal/gal.dart';
import 'package:share_plus/share_plus.dart';
import '../services/subscription_service.dart';

class CameraOverlayScreen extends StatefulWidget {
  final List<CameraDescription> cameras;

  const CameraOverlayScreen({super.key, required this.cameras});

  @override
  State<CameraOverlayScreen> createState() => _CameraOverlayScreenState();
}

class _CameraOverlayScreenState extends State<CameraOverlayScreen> {
  CameraController? _controller;
  int _selectedCameraIndex = 0;
  bool _isCameraReady = false;
  FlashMode _flashMode = FlashMode.off;

  // Overlay state variables
  File? _overlayImage;
  double _opacity = 0.5;
  Offset _offset = Offset.zero;
  double _scale = 1.0;
  double _baseScale = 1.0;
  double _rotation = 0.0;
  double _baseRotation = 0.0;

  // Monetization state
  int _freeRemaining = 3;
  bool _isPro = false;

  // Captured output
  XFile? _capturedFile;

  @override
  void initState() {
    super.initState();
    _refreshSubscriptionStatus();
    if (widget.cameras.isNotEmpty) {
      _initCameraController(widget.cameras[_selectedCameraIndex]);
    }
  }

  Future<void> _refreshSubscriptionStatus() async {
    final pro = await SubscriptionService.isProActive();
    final rem = await SubscriptionService.getRemainingFreeReferences();
    if (mounted) {
      setState(() {
        _isPro = pro;
        _freeRemaining = rem;
      });
    }
  }

  bool get _isRearCamera {
    if (widget.cameras.isEmpty) return false;
    return widget.cameras[_selectedCameraIndex].lensDirection == CameraLensDirection.back;
  }

  Future<void> _initCameraController(CameraDescription camera) async {
    final prevController = _controller;
    final newController = CameraController(
      camera,
      ResolutionPreset.max,
      enableAudio: false,
    );

    await prevController?.dispose();

    if (mounted) {
      setState(() {
        _controller = newController;
        _isCameraReady = false;
        _flashMode = FlashMode.off;
      });
    }

    try {
      await newController.initialize();
      await newController.setFlashMode(FlashMode.off);
      if (mounted) {
        setState(() {
          _isCameraReady = true;
        });
      }
    } catch (e) {
      debugPrint("Camera initialization error: $e");
    }
  }

  void _switchCamera() {
    if (widget.cameras.length < 2) return;
    _selectedCameraIndex = (_selectedCameraIndex + 1) % widget.cameras.length;
    _initCameraController(widget.cameras[_selectedCameraIndex]);
  }

  void _rotateOverlay90() {
    setState(() {
      _rotation += math.pi / 2;
    });
  }

  Future<void> _toggleFlash() async {
    if (_controller == null || !_controller!.value.isInitialized || !_isRearCamera) return;
    final nextMode = _flashMode == FlashMode.off ? FlashMode.torch : FlashMode.off;
    try {
      await _controller!.setFlashMode(nextMode);
      setState(() {
        _flashMode = nextMode;
      });
    } catch (e) {
      debugPrint("Flash toggle error: $e");
    }
  }

  Future<void> _pickOverlay() async {
    final canUpload = await SubscriptionService.canUploadReference();
    if (!canUpload) {
      if (!mounted) return;
      _showPaywallDialog();
      return;
    }

    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      await SubscriptionService.recordReferenceUpload();
      await _refreshSubscriptionStatus();
      setState(() {
        _overlayImage = File(picked.path);
        _offset = Offset.zero;
        _scale = 1.0;
        _rotation = 0.0;
      });
    }
  }

  void _showPaywallDialog() {
    final keyController = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF18181B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 24,
          right: 24,
          top: 24,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.amber.shade700,
                borderRadius: BorderRadius.circular(99),
              ),
              child: const Text(
                'PRO UNLIMITED',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.black),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              "You've Used Your 3 Free Reference Images!",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 8),
            const Text(
              'Unlock unlimited reference photo uploads for 1 full month.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                child: Text(
                  '₹499 / 1 Month',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.greenAccent.shade700),
                onPressed: () async {
                  await SubscriptionService.activateOneMonthPro();
                  await _refreshSubscriptionStatus();
                  if (ctx.mounted) Navigator.pop(ctx);
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('🎉 Pro Activated for 1 Month! Unlimited references unlocked.')),
                    );
                  }
                },
                child: const Text(
                  'Pay ₹499 & Unlock 1 Month Pro',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: keyController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'Have a license key? (Try PRO499)',
                      hintStyle: TextStyle(color: Colors.white38, fontSize: 13),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    if (keyController.text.trim().toUpperCase() == 'PRO499') {
                      await SubscriptionService.activateOneMonthPro();
                      await _refreshSubscriptionStatus();
                      if (ctx.mounted) Navigator.pop(ctx);
                    }
                  },
                  child: const Text('Activate', style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _takePhoto() async {
    if (_controller == null || !_controller!.value.isInitialized) return;

    try {
      final file = await _controller!.takePicture();
      await Gal.putImage(file.path);
      setState(() {
        _capturedFile = file;
      });
    } catch (e) {
      debugPrint("Capture failed: $e");
    }
  }

  Future<void> _shareCapturedImage() async {
    if (_capturedFile == null) return;
    final xfile = XFile(_capturedFile!.path);
    await Share.shareXFiles(
      [xfile],
      text: 'Recreated using Ghost Overlay Camera',
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_capturedFile != null) {
      return _buildReviewScreen();
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_isCameraReady && _controller != null)
            Center(child: CameraPreview(_controller!))
          else
            const Center(child: CircularProgressIndicator(color: Colors.white)),

          if (_overlayImage != null)
            Positioned.fill(
              child: GestureDetector(
                onScaleStart: (details) {
                  _baseScale = _scale;
                  _baseRotation = _rotation;
                },
                onScaleUpdate: (details) {
                  setState(() {
                    _scale = (_baseScale * details.scale).clamp(0.2, 5.0);
                    _rotation = _baseRotation + details.rotation;
                    _offset += details.focalPointDelta;
                  });
                },
                child: Transform.translate(
                  offset: _offset,
                  child: Transform.rotate(
                    angle: _rotation,
                    child: Transform.scale(
                      scale: _scale,
                      child: Opacity(
                        opacity: _opacity,
                        child: Image.file(_overlayImage!, fit: BoxFit.contain),
                      ),
                    ),
                  ),
                ),
              ),
            ),

          SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
                  child: Row(
                    children: [
                      const Icon(Icons.opacity, color: Colors.white70),
                      Expanded(
                        child: Slider(
                          value: _opacity,
                          min: 0.0,
                          max: 1.0,
                          activeColor: Colors.white,
                          inactiveColor: Colors.white30,
                          onChanged: (val) => setState(() => _opacity = val),
                        ),
                      ),
                      if (_overlayImage != null)
                        IconButton(
                          icon: const Icon(Icons.rotate_90_degrees_cw, color: Colors.white),
                          tooltip: 'Rotate Reference 90°',
                          onPressed: _rotateOverlay90,
                        ),
                      if (_isRearCamera)
                        IconButton(
                          icon: Icon(
                            _flashMode == FlashMode.torch ? Icons.flash_on : Icons.flash_off,
                            color: Colors.white,
                          ),
                          onPressed: _toggleFlash,
                        ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(99),
                          border: Border.all(color: Colors.white30),
                        ),
                        child: Text(
                          _isPro ? 'PRO' : '$_freeRemaining/3 Free',
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(bottom: 24.0, left: 16.0, right: 16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.photo_library, color: Colors.white, size: 30),
                        tooltip: 'Upload Reference Photo',
                        onPressed: _pickOverlay,
                      ),
                      GestureDetector(
                        onTap: _takePhoto,
                        child: Container(
                          width: 72,
                          height: 72,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 4),
                          ),
                          child: Center(
                            child: Container(
                              width: 58,
                              height: 58,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.flip_camera_ios, color: Colors.white, size: 30),
                        tooltip: 'Rotate / Switch Front & Back Camera',
                        onPressed: widget.cameras.length > 1 ? _switchCamera : null,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewScreen() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.file(File(_capturedFile!.path), fit: BoxFit.contain),
          SafeArea(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
                color: Colors.black87,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    TextButton.icon(
                      icon: const Icon(Icons.replay, color: Colors.white),
                      label: const Text("Retake", style: TextStyle(color: Colors.white)),
                      onPressed: () => setState(() => _capturedFile = null),
                    ),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
                      icon: const Icon(Icons.share, color: Colors.black),
                      label: const Text("Share", style: TextStyle(color: Colors.black)),
                      onPressed: _shareCapturedImage,
                    ),
                    TextButton.icon(
                      icon: const Icon(Icons.check, color: Colors.white),
                      label: const Text("Done", style: TextStyle(color: Colors.white)),
                      onPressed: () {
                        setState(() => _capturedFile = null);
                        Navigator.pop(context);
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
