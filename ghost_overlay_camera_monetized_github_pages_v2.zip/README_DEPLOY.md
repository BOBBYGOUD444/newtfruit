# Ghost Overlay Camera – v2 (Monetized + GitHub Pages Ready)

## Included inside this single ZIP bundle:
1. **`github_pages_web/`**: Zero-build HTML5/JS/CSS web application ready for instant GitHub Pages deployment (`index.html`, `style.css`, `app.js`).
2. **`flutter_app/`**: Full Flutter mobile source code with `SubscriptionService` (3 Free Reference uploads -> ₹499/month Pro Unlimited), Camera Flip/Rotation, 90° Overlay Rotation, and Native Share Sheet (`share_plus`).

---

## How to Deploy to GitHub Pages in 60 Seconds
1. Create a new GitHub repository and upload the files inside `github_pages_web/` (`index.html`, `style.css`, `app.js`) to the root of your repository.
2. Go to **Settings -> Pages** in your GitHub repository.
3. Under **Build and deployment**, select **Deploy from a branch** and choose `main` (root `/`).
4. Open your live `https://<username>.github.io/<repo>/` URL on mobile or desktop! (HTTPS is automatically provided by GitHub Pages, which is required for live camera streaming and native Web Share).
