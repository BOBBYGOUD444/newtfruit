// Monetization & Reference Counter State (3 Free References -> ₹499/mo Pro)
const MAX_FREE_REFS = 3;
let usedRefs = parseInt(localStorage.getItem('ghost_used_refs') || '0', 10);
let proExpiry = parseInt(localStorage.getItem('ghost_pro_expiry') || '0', 10);

// Camera & Transform State
let currentFacingMode = 'environment'; // 'environment' (rear) or 'user' (front)
let mediaStream = null;
let posX = 0, posY = 0, scale = 1, rotation = 0;
let isDragging = false, startX = 0, startY = 0;
let initialPinchDistance = null, initialScale = 1;

// DOM Elements
const homeScreen = document.getElementById('home-screen');
const cameraScreen = document.getElementById('camera-screen');
const reviewScreen = document.getElementById('review-screen');
const paywallModal = document.getElementById('paywall-modal');

const tierBadge = document.getElementById('tier-badge');
const camUsagePill = document.getElementById('cam-usage-pill');
const videoEl = document.getElementById('camera-stream');
const overlayContainer = document.getElementById('overlay-container');
const overlayImg = document.getElementById('overlay-img');
const opacitySlider = document.getElementById('opacity-slider');
const fileInput = document.getElementById('file-input');
const captureCanvas = document.getElementById('capture-canvas');

function isProActive() {
  return Date.now() < proExpiry;
}

function updateMonetizationUI() {
  if (isProActive()) {
    const daysLeft = Math.ceil((proExpiry - Date.now()) / (1000 * 60 * 60 * 24));
    tierBadge.innerHTML = `🌟 PRO Active (${daysLeft}d left)`;
    camUsagePill.textContent = 'PRO Unlimited';
  } else {
    const remaining = Math.max(0, MAX_FREE_REFS - usedRefs);
    tierBadge.innerHTML = `Free Tier: <span>${remaining}</span>/${MAX_FREE_REFS} Left`;
    camUsagePill.textContent = `${remaining}/${MAX_FREE_REFS} Free`;
  }
}

updateMonetizationUI();

// Start Camera
document.getElementById('start-camera-btn').addEventListener('click', async () => {
  homeScreen.classList.remove('active');
  cameraScreen.classList.add('active');
  await startCamera(currentFacingMode);
});

document.getElementById('back-home-btn').addEventListener('click', () => {
  stopCamera();
  cameraScreen.classList.remove('active');
  homeScreen.classList.add('active');
});

// Reset Demo Counter for testing
document.getElementById('reset-demo-btn').addEventListener('click', () => {
  localStorage.removeItem('ghost_used_refs');
  localStorage.removeItem('ghost_pro_expiry');
  usedRefs = 0;
  proExpiry = 0;
  updateMonetizationUI();
  alert('Demo Reset: You have 3 free reference images again.');
});

async function startCamera(facingMode) {
  stopCamera();
  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: facingMode }, width: { ideal: 1920 }, height: { ideal: 1080 } },
      audio: false
    });
    videoEl.srcObject = mediaStream;
  } catch (err) {
    console.error('Camera Error:', err);
    alert('Please allow camera access in your browser settings.');
  }
}

function stopCamera() {
  if (mediaStream) {
    mediaStream.getTracks().forEach(t => t.stop());
    mediaStream = null;
  }
}

// Camera Rotation / Flip Front & Rear Camera
document.getElementById('switch-camera-btn').addEventListener('click', async () => {
  currentFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
  videoEl.style.transform = currentFacingMode === 'user' ? 'scaleX(-1)' : 'scaleX(1)';
  await startCamera(currentFacingMode);
});

// Intercept Reference Upload if 3 Free Used
document.getElementById('upload-label').addEventListener('click', (e) => {
  if (!isProActive() && usedRefs >= MAX_FREE_REFS) {
    e.preventDefault();
    paywallModal.classList.remove('hidden');
  }
});

fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  if (!isProActive()) {
    if (usedRefs >= MAX_FREE_REFS) {
      paywallModal.classList.remove('hidden');
      fileInput.value = '';
      return;
    }
    usedRefs++;
    localStorage.setItem('ghost_used_refs', usedRefs.toString());
    updateMonetizationUI();
  }

  const reader = new FileReader();
  reader.onload = (ev) => {
    overlayImg.src = ev.target.result;
    overlayContainer.classList.remove('hidden');
    resetOverlayTransform();
  };
  reader.readAsDataURL(file);
});

// Opacity & Overlay Rotation Controls
opacitySlider.addEventListener('input', (e) => {
  overlayImg.style.opacity = e.target.value / 100;
});

document.getElementById('rotate-overlay-btn').addEventListener('click', () => {
  rotation = (rotation + 90) % 360;
  applyOverlayTransform();
});

document.getElementById('reset-overlay-btn').addEventListener('click', resetOverlayTransform);

function resetOverlayTransform() {
  posX = 0; posY = 0; scale = 1; rotation = 0;
  applyOverlayTransform();
}

function applyOverlayTransform() {
  overlayImg.style.transform = `translate(${posX}px, ${posY}px) rotate(${rotation}deg) scale(${scale})`;
}

// Drag & Pinch-to-Zoom Gestures
overlayContainer.addEventListener('pointerdown', (e) => {
  isDragging = true;
  startX = e.clientX - posX;
  startY = e.clientY - posY;
});

window.addEventListener('pointermove', (e) => {
  if (!isDragging) return;
  posX = e.clientX - startX;
  posY = e.clientY - startY;
  applyOverlayTransform();
});

window.addEventListener('pointerup', () => { isDragging = false; });

overlayContainer.addEventListener('touchstart', (e) => {
  if (e.touches.length === 2) {
    isDragging = false;
    initialPinchDistance = Math.hypot(
      e.touches[0].pageX - e.touches[1].pageX,
      e.touches[0].pageY - e.touches[1].pageY
    );
    initialScale = scale;
  }
});

overlayContainer.addEventListener('touchmove', (e) => {
  if (e.touches.length === 2 && initialPinchDistance) {
    const currentDist = Math.hypot(
      e.touches[0].pageX - e.touches[1].pageX,
      e.touches[0].pageY - e.touches[1].pageY
    );
    scale = Math.min(Math.max(0.2, initialScale * (currentDist / initialPinchDistance)), 5);
    applyOverlayTransform();
  }
});

// Capture Photo
document.getElementById('capture-btn').addEventListener('click', () => {
  const vw = videoEl.videoWidth || 1080;
  const vh = videoEl.videoHeight || 1920;
  captureCanvas.width = vw;
  captureCanvas.height = vh;
  const ctx = captureCanvas.getContext('2d');

  if (currentFacingMode === 'user') {
    ctx.translate(vw, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(videoEl, 0, 0, vw, vh);

  cameraScreen.classList.remove('active');
  reviewScreen.classList.add('active');
});

document.getElementById('retake-btn').addEventListener('click', () => {
  reviewScreen.classList.remove('active');
  cameraScreen.classList.add('active');
});

document.getElementById('done-btn').addEventListener('click', () => {
  reviewScreen.classList.remove('active');
  cameraScreen.classList.add('active');
});

// Native Web Share + Fallback Image Download
document.getElementById('share-btn').addEventListener('click', async () => {
  captureCanvas.toBlob(async (blob) => {
    if (!blob) return;
    const file = new File([blob], `ghost_capture_${Date.now()}.png`, { type: 'image/png' });

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: 'Ghost Overlay Camera Shot',
          text: 'Recreated using Ghost Overlay Camera!'
        });
        return;
      } catch (err) {
        console.log('Share dismissed or fallback needed:', err);
      }
    }

    // Fallback: Direct download if desktop or browser doesn't support file share
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = file.name;
    a.click();
  }, 'image/png');
});

// Monetization: ₹499 / 1 Month Activation
function activateOneMonthPro() {
  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
  proExpiry = Date.now() + thirtyDaysMs;
  localStorage.setItem('ghost_pro_expiry', proExpiry.toString());
  updateMonetizationUI();
  paywallModal.classList.add('hidden');
  alert('🎉 Ghost Overlay PRO Activated for 1 Month! Enjoy unlimited reference images.');
}

document.getElementById('buy-pro-btn').addEventListener('click', () => {
  // Razorpay Checkout Integration (Test Mode / Mock Ready)
  if (typeof Razorpay !== 'undefined') {
    const options = {
      key: 'rzp_test_YourTestKeyHere', // Replace with live Razorpay Key ID in production
      amount: 49900, // 49900 paise = ₹499
      currency: 'INR',
      name: 'Ghost Overlay Camera',
      description: '1 Month Unlimited Reference Images Pass',
      handler: function (response) {
        activateOneMonthPro();
      }
    };
    try {
      const rzp = new Razorpay(options);
      rzp.open();
      return;
    } catch (e) {
      console.log('Fallback to instant demo activation');
    }
  }
  activateOneMonthPro();
});

document.getElementById('verify-key-btn').addEventListener('click', () => {
  const code = document.getElementById('license-input').value.trim().toUpperCase();
  if (code === 'PRO499' || code === 'GHOST499') {
    activateOneMonthPro();
  } else {
    alert('Invalid key. Use demo key: PRO499');
  }
});

document.getElementById('close-paywall-btn').addEventListener('click', () => {
  paywallModal.classList.add('hidden');
});
